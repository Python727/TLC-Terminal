-- ============================================================================
--   Reads a JSON file every 5 seconds, checks for waypoint requests,
--   spawns or destroys a BP_Waypoint actor accordingly, and writes
--   the current player position back to the JSON file.
-- ============================================================================

-- ==================== CONFIGURATION ====================
local PLAYER_CLASS = "BP_FirstPersonCharacter_New_C"
local TIMER_INTERVAL_MS = 5000

-- Blueprint class search paths. The first valid one found is cached.
-- Adjust these if your .pak mounts the blueprint under a different path.
local BP_WAYPOINT_PATHS = {
    "/Game/Mods/TerminalWaypoint/BP_Waypoint.BP_Waypoint_C",
    "/Mods/TerminalWaypoint/BP_Waypoint.BP_Waypoint_C",
    "BlueprintGeneratedClass /Game/Mods/TerminalWaypoint/BP_Waypoint.BP_Waypoint_C",
    "BlueprintGeneratedClass /Mods/TerminalWaypoint/BP_Waypoint.BP_Waypoint_C"
}
-- =======================================================

-- ==================== AUTO-DETECT JSON PATH ====================
-- Derives the JSON file location from this script's own path.
-- If the script is at:  .../Mods/TerminalWaypoint/Scripts/main.lua
-- The JSON will be at:  .../Mods/TerminalWaypoint/waypoint.json
local JSON_PATH = nil
do
    local src = debug.getinfo(1, "S").source
    if src and src:sub(1, 1) == "@" then src = src:sub(2) end
    src = src:gsub("/", "\\")
    local idx = src:find("\\Scripts\\main%.lua$")
    if idx then
        JSON_PATH = src:sub(1, idx - 1) .. "\\waypoint.json"
    else
        -- Fallback if path auto-detection fails
        JSON_PATH = ".\\Mods\\TerminalWaypoint\\waypoint.json"
    end
end

-- Ensure the mod folder exists so io.open can create the JSON file.
local function EnsureDir(path)
    local dir = path:match("(.+)\\[^\\]*$")
    if dir then os.execute('if not exist "' .. dir .. '" mkdir "' .. dir .. '"') end
end
EnsureDir(JSON_PATH)
-- =====================================================

-- ==================== INTERNAL STATE ====================
-- Mirrors the JSON structure. Updated every tick and written back.
local WaypointState = {
    PlayerPos = {X = 0.0, Y = 0.0, Z = 0.0}, -- Live player location
    BoatPos   = {X = 0.0, Y = 0.0, Z = 0.0}, -- Live boat location
    Request = 0, -- 1=create, -1=destroy, 0=idle
    Waypoint = {X = 0.0, Y = 0.0, Z = 0.0},  -- Last known waypoint position
    IsWaypointActive = false -- True if a waypoint actor exists
}
local CachedWaypointClass = nil  -- Found once, reused forever
-- =====================================================

-- ==================== JSON PARSING ====================
-- Extracts a Vector3 object like {"X":1.0,"Y":2.0,"Z":3.0} from raw JSON text
local function ParseVector(content, field)
    local pat = '"' .. field .. '"%s*:%s*{%s*"X"%s*:%s*([%d%.%-]+)%s*,%s*"Y"%s*:%s*([%d%.%-]+)%s*,%s*"Z"%s*:%s*([%d%.%-]+)%s*}'
    local x, y, z = content:match(pat)
    return {X = tonumber(x) or 0.0, Y = tonumber(y) or 0.0, Z = tonumber(z) or 0.0}
end

-- Parses the entire waypoint.json
local function ParseJson(content)
    local d = {}
    d.PlayerPos = ParseVector(content, "PlayerPos")
    d.BoatPos   = ParseVector(content, "BoatPos")
    d.Waypoint = ParseVector(content, "Waypoint")
    d.Request  = tonumber(content:match('"Request"%s*:%s*([%d%-]+)')) or 0
    d.IsWaypointActive = (content:match('"IsWaypointActive"%s*:%s*(true)') ~= nil)
    return d
end

-- Converts the state table back into formatted JSON
local function SerializeJson(data)
    return string.format(
[[{
    "PlayerPos": {"X": %.2f, "Y": %.2f, "Z": %.2f},
    "BoatPos": {"X": %.2f, "Y": %.2f, "Z": %.2f},
    "Request": %d,
    "Waypoint": {"X": %.2f, "Y": %.2f, "Z": %.2f},
    "IsWaypointActive": %s
}]],
        data.PlayerPos.X, data.PlayerPos.Y, data.PlayerPos.Z,
        data.BoatPos.X,   data.BoatPos.Y,   data.BoatPos.Z,
        data.Request,
        data.Waypoint.X, data.Waypoint.Y, data.Waypoint.Z,
        data.IsWaypointActive and "true" or "false"
    )
end

-- Reads waypoint.json from disk
local function ReadJson()
    local f = io.open(JSON_PATH, "r")
    if not f then return nil end
    local txt = f:read("*a")
    f:close()
    if not txt or txt == "" then return nil end
    local ok, data = pcall(function() return ParseJson(txt) end)
    if ok and data then return data end
    return nil
end

-- Overwrites waypoint.json with the current state
local function WriteJson(data)
    EnsureDir(JSON_PATH)
    local f = io.open(JSON_PATH, "w")
    if not f then return false end
    f:write(SerializeJson(data))
    f:close()
    return true
end
-- =====================================================

-- ==================== BLUEPRINT CLASS LOOKUP ====================
-- Finds the BP_Waypoint BlueprintGeneratedClass in memory
local function GetWaypointClass()
    if CachedWaypointClass and CachedWaypointClass:IsValid() then
        return CachedWaypointClass
    end
    for _, p in ipairs(BP_WAYPOINT_PATHS) do
        local cls = StaticFindObject(p)
        if cls and cls:IsValid() then
            CachedWaypointClass = cls
            return cls
        end
    end
    for _, p in ipairs(BP_WAYPOINT_PATHS) do
        local cls = StaticLoadObject(p)
        if cls and cls:IsValid() then
            CachedWaypointClass = cls
            return cls
        end
    end
    return nil
end
-- =====================================================

-- ==================== PLAYER PAWN DISCOVERY ====================
local function GetPlayerPawn()
    if PLAYER_CLASS and PLAYER_CLASS ~= "" then
        local char = FindFirstOf(PLAYER_CLASS)
        if char and char:IsValid() then return char end
        local chars = FindAllOf(PLAYER_CLASS)
        if chars then
            for _, c in pairs(chars) do
                if c and c:IsValid() then return c end
            end
        end
    end
    local controllers = FindAllOf("PlayerController")
    if controllers then
        for _, pc in pairs(controllers) do
            if pc and pc:IsValid() then
                local ok, pawn = pcall(function() return pc.Pawn end)
                if ok and pawn then
                    local ok2, valid = pcall(function() return pawn:IsValid() end)
                    if ok2 and valid then return pawn end
                end
            end
        end
    end
    local chars = FindAllOf("Character")
    if chars then
        for _, c in pairs(chars) do
            if c and c:IsValid() then return c end
        end
    end
    local pawns = FindAllOf("Pawn")
    if pawns then
        for _, p in pairs(pawns) do
            if p and p:IsValid() then return p end
        end
    end
    return nil
end

-- Gets player's current location
local function GetPlayerLocation()
    local pawn = GetPlayerPawn()
    if not pawn then return {X = 0.0, Y = 0.0, Z = 0.0} end
    local ok, loc = pcall(function() return pawn:K2_GetActorLocation() end)
    if ok and loc then return {X = loc.X or 0.0, Y = loc.Y or 0.0, Z = loc.Z or 0.0} end
    ok, loc = pcall(function() return pawn:GetActorLocation() end)
    if ok and loc then return {X = loc.X or 0.0, Y = loc.Y or 0.0, Z = loc.Z or 0.0} end
    return {X = 0.0, Y = 0.0, Z = 0.0}
end

-- Gets the boat's current location
local function GetBoatLocation()
    local boat = FindFirstOf("BP_Boat_Barge_C")
    if not boat then return {X = 0.0, Y = 0.0, Z = 0.0} end
    local ok, valid = pcall(function() return boat:IsValid() end)
    if not ok or not valid then return {X = 0.0, Y = 0.0, Z = 0.0} end
    local okL, loc = pcall(function() return boat:K2_GetActorLocation() end)
    if okL and loc then return {X = loc.X or 0.0, Y = loc.Y or 0.0, Z = loc.Z or 0.0} end
    okL, loc = pcall(function() return boat:GetActorLocation() end)
    if okL and loc then return {X = loc.X or 0.0, Y = loc.Y or 0.0, Z = loc.Z or 0.0} end
    return {X = 0.0, Y = 0.0, Z = 0.0}
end
-- =====================================================

-- ==================== WORLD ACQUISITION ====================
local function GetGameWorld()
    local pc = FindFirstOf("PlayerController")
    if pc and pc:IsValid() then
        local ok, world = pcall(function() return pc:GetWorld() end)
        if ok and world then
            local ok2, valid = pcall(function() return world:IsValid() end)
            if ok2 and valid then return world end
        end
    end
    local pawn = GetPlayerPawn()
    if pawn then
        local ok, world = pcall(function() return pawn:GetWorld() end)
        if ok and world then
            local ok2, valid = pcall(function() return world:IsValid() end)
            if ok2 and valid then return world end
        end
    end
    local world = FindFirstOf("World")
    if world then
        local ok, valid = pcall(function() return world:IsValid() end)
        if ok and valid then return world end
    end
    return nil
end
-- =====================================================

-- ==================== WAYPOINT MANAGEMENT ====================
local function CountWaypoints()
    local wps = FindAllOf("BP_Waypoint_C")
    local n = 0
    if wps then
        for _, wp in pairs(wps) do
            if wp then
                local ok, valid = pcall(function() return wp:IsValid() end)
                if ok and valid then n = n + 1 end
            end
        end
    end
    return n
end

-- Destroys every BP_Waypoint_C instance in world
local function DestroyAllWaypoints()
    local wps = FindAllOf("BP_Waypoint_C")
    local destroyed = false
    if wps then
        for _, wp in pairs(wps) do
            if wp then
                local ok, valid = pcall(function() return wp:IsValid() end)
                if ok and valid then
                    pcall(function() wp:K2_DestroyActor() end)
                    destroyed = true
                end
            end
        end
    end
    if destroyed then
        print("Waypoint removed")
    end
end

local function MakeVector(x, y, z)
    if _G.FVector then return FVector(x, y, z) else return {X = x, Y = y, Z = z} end
end
local function MakeRotator(pitch, yaw, roll)
    if _G.FRotator then return FRotator(pitch, yaw, roll) else return {Pitch = pitch, Yaw = yaw, Roll = roll} end
end

-- Spawn new BP_Waypoint actor at given coordinates
local function SpawnWaypoint(pos)
    local cls = GetWaypointClass()
    if not cls then return nil end
    local world = GetGameWorld()
    if not world then return nil end
    local loc = MakeVector(pos.X, pos.Y, pos.Z)
    local rot = MakeRotator(0, 0, 0)
    -- Try standard 3-arg spawn, then 4-arg with empty params table
    local ok, actor = pcall(function() return world:SpawnActor(cls, loc, rot) end)
    if not ok then
        ok, actor = pcall(function() return world:SpawnActor(cls, loc, rot, {}) end)
    end
    if ok and actor then
        local okA, validA = pcall(function() return actor:IsValid() end)
        if okA and validA then
            print(string.format("Waypoint created at %.1f, %.1f, %.1f", pos.X, pos.Y, pos.Z))
            return actor
        end
    end
    return nil
end
-- =====================================================

-- ==================== MAIN REQUEST PROCESSOR ====================
-- REQUEST VALUES:
--   1  = Create waypoint at "Waypoint" vector in JSON.
--        After spawning, Request is reset to 0 and IsWaypointActive becomes true.
--  -1  = Destroy all existing waypoints.
--        After destroying, Request is reset to 0 and IsWaypointActive becomes false.
--   0  = Idle. Just syncs IsWaypointActive to reality and updates player position.
local function ProcessRequest()
    -- 1. Read external request from JSON
    local jsonData = ReadJson()
    if jsonData then
        WaypointState.Request = jsonData.Request
        WaypointState.Waypoint = jsonData.Waypoint
        WaypointState.IsWaypointActive = jsonData.IsWaypointActive
    end

    -- 2. Always refresh player and boat location (even in idle mode)
    WaypointState.PlayerPos = GetPlayerLocation()
    WaypointState.BoatPos   = GetBoatLocation()

    local req = WaypointState.Request

    if req == 1 then
        -- CREATE: destroy old waypoints first, then spawn new one
        DestroyAllWaypoints()
        local wp = SpawnWaypoint(WaypointState.Waypoint)
        if wp then
            WaypointState.IsWaypointActive = true
        else
            WaypointState.IsWaypointActive = false
            WaypointState.Waypoint = {X = 0.0, Y = 0.0, Z = 0.0}
        end
        WaypointState.Request = 0 -- mark as handled

    elseif req == -1 then
        -- DESTROY: kill all waypoints and zero out state
        DestroyAllWaypoints()
        WaypointState.IsWaypointActive = false
        WaypointState.Waypoint = {X = 0.0, Y = 0.0, Z = 0.0}
        WaypointState.Request = 0 -- mark as handled

    else
        -- set IsWaypointActive to actual actor count
        local count = CountWaypoints()
        WaypointState.IsWaypointActive = (count > 0)
        if count == 0 then
            WaypointState.Waypoint = {X = 0.0, Y = 0.0, Z = 0.0}
        end
    end

    -- Write to JSON
    WriteJson(WaypointState)
end
-- =====================================================

-- ==================== INITIALISATION ====================
-- Create default JSON file on first boot (if missing)
local test = io.open(JSON_PATH, "r")
if not test then
    WriteJson(WaypointState)
else
    test:close()
end

-- Start the automatic 5-second loop.
-- The callback is stored in _G to prevent Lua garbage collection.
-- Returning false from LoopAsync means "keep looping"; true will stop it.
_G.TerminalWaypoint_TimerCallback = function()
    ExecuteInGameThread(function()
        local ok, err = pcall(ProcessRequest)
        if not ok then print("[TerminalWaypoint] Timer error: " .. tostring(err)) end
    end)
    return false
end

LoopAsync(TIMER_INTERVAL_MS, _G.TerminalWaypoint_TimerCallback)
-- =====================================================